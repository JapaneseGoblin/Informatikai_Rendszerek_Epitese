import { Routes } from '@angular/router';
import { UserSearchComponent } from './pages/user-search/user-search.component';
import { RepoSearchComponent } from '/pages/repo-search/repo-search.component';
import { UserDetailComponent } from './pages/user-detail/user-detail.component';
import { RepoDetailComponent } from './pages/repo-detail/repo-detail.component';

export const routes: Routes = [
  { path: '', component: UserSearchComponent },
  { path: 'search-repos', component: RepoSearchComponent },
  { path: 'user/:username', component: UserDetailComponent },
  { path: 'repo/:owner/:repo', component: RepoDetailComponent },
];