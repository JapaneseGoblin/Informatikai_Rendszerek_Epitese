import { Component } from '@angular/core';

@Component({
  selector: 'app-repo-search',
  imports: [],
  templateUrl: './repo-search.html',
  styleUrl: './repo-search.css',
})
export class RepoSearch {

}
