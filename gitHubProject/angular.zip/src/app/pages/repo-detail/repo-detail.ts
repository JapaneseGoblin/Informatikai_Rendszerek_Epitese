import { Component } from '@angular/core';

@Component({
  selector: 'app-repo-detail',
  imports: [],
  templateUrl: './repo-detail.html',
  styleUrl: './repo-detail.css',
})
export class RepoDetail {

}
